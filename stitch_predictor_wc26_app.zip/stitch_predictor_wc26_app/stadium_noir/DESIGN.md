# Design System Strategy: The Stadium Pulse

## 1. Overview & Creative North Star
This design system is built to capture the high-stakes, kinetic energy of a global sporting event. Our Creative North Star is **"The Stadium Pulse."** 

We are moving away from the "standard SaaS dashboard" aesthetic. Instead, we are leaning into high-end sports editorial—think digital scoreboards, premium broadcast overlays, and large-format environmental graphics. The experience must feel immersive, utilizing heavy-weight typography and deep, layered blacks to make the vibrant green accents feel like they are glowing under stadium floodlights. We break the "template" look through intentional asymmetry: large scores might overlap container edges, and typography scales will shift dramatically to create a sense of urgency and importance.

## 2. Colors & Surface Architecture
The palette is rooted in a "Pure Dark" philosophy. The depth of the interface is not created by lines, but by the physical stacking of light and texture.

*   **Primary Accent (`#3fff8b`):** This is our "Action Green." It represents the pitch, the "go" signal, and active data. Use it sparingly but boldly for CTAs, active states, and critical success metrics.
*   **The "No-Line" Rule:** To maintain a premium editorial feel, **1px solid borders are strictly prohibited** for sectioning or layout. Boundaries between content areas must be defined exclusively through background shifts (e.g., a `surface-container-low` card resting on a `surface` background) or vertical whitespace. 
*   **Surface Hierarchy & Nesting:** Treat the UI as a series of physical layers. 
    *   The base layer is always `surface` (`#0e0e0e`).
    *   Nested content areas use `surface-container-low` (`#131313`) or `surface-container-high` (`#201f1f`) to create a sense of lift.
    *   The most important interactive elements should sit on `surface-container-highest` (`#262626`).
*   **The "Glass & Gradient" Rule:** Floating overlays (modals, tooltips, or "sticky" score trackers) should utilize Glassmorphism. Apply `surface-variant` with a 60% opacity and a 12px-20px backdrop-blur. 
*   **Signature Textures:** For high-impact areas like Hero sections or winning predictions, use a subtle "Noise" overlay (2-3% opacity) combined with a linear gradient moving from `primary` (#3fff8b) to `primary-container` (#13ea79) at a 45-degree angle.

## 3. Typography: Editorial Impact
Our typography is designed to mimic the authoritative weight of a stadium scoreboard.

*   **Display & Headlines (Lexend):** This is our "Voice of Authority." Use `display-lg` and `headline-lg` for scores and major titles. Don't be afraid of tight letter-spacing (-2%) on display styles to create a "compacted" scoreboard feel.
*   **Body & Utility (Manrope):** This is our "Data Voice." It provides the clean, technical counterpoint to the aggressive Lexend headings. Use `body-md` for standard stats and `label-sm` for secondary metadata. 
*   **Visual Hierarchy:** Establish a "High-Contrast" scale. If a score is in `display-lg`, the supporting label should be `label-md` or `label-sm`. The extreme difference in size creates a premium, intentional design language rather than a "middle-of-the-road" generic list.

## 4. Elevation & Depth
In this design system, depth is a product of light and layering, not structural boxes.

*   **The Layering Principle:** Instead of shadows, use "Tonal Stepping." Place a `surface-container-lowest` element inside a `surface-container-high` area to create an "inset" look, or vice-versa to create "lift."
*   **Ambient Shadows:** If a component *must* float (like a floating action button or a modal), use an ultra-diffused shadow. 
    *   **Shadow:** `0px 24px 48px rgba(0, 0, 0, 0.4)`. 
    *   The shadow should never be harsh; it should feel like the component is occluding the ambient light of the screen.
*   **The "Ghost Border" Fallback:** For accessibility in complex data tables where background shifts aren't enough, use a "Ghost Border." Use `outline-variant` (`#484847`) at **15% opacity**. This provides a hint of a container without breaking the editorial flow.
*   **Kinetic Glass:** For score cards that update in real-time, use a semi-transparent `surface-container` with a backdrop blur to let the "Stadium Noise" background texture bleed through.

## 5. Components

### Buttons
*   **Primary:** Solid `primary` (`#3fff8b`) background with `on_primary` text. Use `DEFAULT` (0.25rem) rounding for a technical, sharp look.
*   **Secondary:** `surface-container-highest` background with `on_surface` text. No border.
*   **Interaction:** On hover, primary buttons should "glow"—add a soft outer shadow using the `primary` color at 20% opacity.

### Cards & Score Modules
*   **Structure:** No dividers. Use `surface-container-low` backgrounds. 
*   **Padding:** Use generous internal padding (refer to the `xl` or `lg` spacing tokens) to let the data breathe.
*   **Editorial Flare:** Place the team abbreviations or large match numbers in `display-sm` Lexend, partially cropped or low-opacity behind the main data to create a "layered" graphic effect.

### Input Fields
*   **State:** Default state uses `surface-container-highest`. 
*   **Active:** When focused, the background remains the same, but the `outline` token is applied at 100% opacity as a "Ghost Border" to signal the active state.
*   **Error:** Use `error_dim` (`#d7383b`) for text and `error_container` for the background of the field.

### Progress Bars & Gauges (Predictor specific)
*   For win probabilities or poll results, use a gradient fill: `primary` to `secondary`. This adds "soul" to the data that a flat green cannot provide.

## 6. Do’s and Don’ts

### Do:
*   **Do** use extreme typographic scales (e.g., a massive `display-lg` score next to a tiny `label-sm` timestamp).
*   **Do** use background tonal shifts to separate "The Header" from "The Feed."
*   **Do** apply a subtle noise texture to the `background` (`#0e0e0e`) to prevent it from looking like a "flat" digital black.
*   **Do** treat the vibrant green (`#3fff8b`) as a high-value resource. Use it to draw the eye to the most important "Win" or "Action."

### Don’t:
*   **Don’t** use 1px solid borders to create grids. It ruins the editorial "flow."
*   **Don’t** use pure white (`#ffffff`) for secondary text; use `on_surface_variant` (`#adaaaa`) to maintain the dark-mode hierarchy.
*   **Don’t** use "pill" (full-round) buttons unless they are small tags/chips. Our primary buttons should feel structural and architectural (0.25rem rounding).
*   **Don’t** use standard drop shadows. If it doesn't feel like it’s floating in a physical space with ambient light, it doesn't belong in this system.